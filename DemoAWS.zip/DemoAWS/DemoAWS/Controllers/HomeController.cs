﻿using DemoAWS.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DemoAWS.Controllers
{
    public class HomeController : Controller
    {
        private readonly GestionBanquesContext context;

        public HomeController(GestionBanquesContext _context)
        {
            context = _context;
        }
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Customers()
        {
            return View(context.Clients);
        }
    }
}
