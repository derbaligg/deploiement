﻿using System;
using Microsoft.EntityFrameworkCore;

namespace DemoAWS.Models
{
    public partial class GestionBanquesContext : DbContext
    {
        public GestionBanquesContext()
        {
        }

        public GestionBanquesContext(DbContextOptions<GestionBanquesContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Clients> Clients { get; set; }

//        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
//        {
//            if (!optionsBuilder.IsConfigured)
//            {
//#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
//                optionsBuilder.UseSqlServer();
//            }
//        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Clients>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Nom)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Prenom)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Telephone)
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
