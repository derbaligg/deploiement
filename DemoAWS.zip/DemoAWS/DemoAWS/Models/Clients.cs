﻿using System;
using System.Collections.Generic;

namespace DemoAWS.Models
{
    public partial class Clients
    {
        public int Id { get; set; }
        public string Nom { get; set; }
        public string Prenom { get; set; }
        public string Telephone { get; set; }
    }
}
